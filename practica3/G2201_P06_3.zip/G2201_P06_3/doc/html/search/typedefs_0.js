var searchData=
[
  ['info',['info',['../ejercicio2_8c.html#adc60ad5b4dd36c641c415957426138f1',1,'info():&#160;ejercicio2.c'],['../ejercicio2b_8c.html#adc60ad5b4dd36c641c415957426138f1',1,'info():&#160;ejercicio2b.c'],['../ejercicio5_8c.html#adc60ad5b4dd36c641c415957426138f1',1,'info():&#160;ejercicio5.c']]]
];
