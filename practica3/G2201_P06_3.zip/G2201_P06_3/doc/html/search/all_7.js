var searchData=
[
  ['semaforos_2ec',['semaforos.c',['../semaforos_8c.html',1,'']]],
  ['semaforos_2eh',['semaforos.h',['../semaforos_8h.html',1,'']]],
  ['shm',['shm',['../ejercicio6_8c.html#ab5066d1a2f90490cfb3dfe798e5eb250',1,'ejercicio6.c']]],
  ['status',['Status',['../semaforos_8h.html#ac6da7dbdb040b28d3e9a7796a06a9e15',1,'semaforos.h']]]
];
