var searchData=
[
  ['crear_5fsemaforo',['Crear_Semaforo',['../semaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c'],['../semaforos_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c']]]
];
