var searchData=
[
  ['_5fbuffer',['_buffer',['../struct__buffer.html',1,'']]],
  ['_5finfo',['_info',['../struct__info.html',1,'']]],
  ['_5fstatus',['_Status',['../semaforos_8h.html#a97d634e5438878a48392ecc66af00648',1,'semaforos.h']]]
];
