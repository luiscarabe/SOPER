var searchData=
[
  ['_5fbuffer',['_buffer',['../struct__buffer.html',1,'']]],
  ['_5finfo',['_info',['../struct__info.html',1,'']]]
];
