var searchData=
[
  ['info',['info',['../ejercicio2_8c.html#adc60ad5b4dd36c641c415957426138f1',1,'info():&#160;ejercicio2.c'],['../ejercicio2b_8c.html#adc60ad5b4dd36c641c415957426138f1',1,'info():&#160;ejercicio2b.c'],['../ejercicio5_8c.html#adc60ad5b4dd36c641c415957426138f1',1,'info():&#160;ejercicio5.c']]],
  ['inicializar_5fsemaforo',['Inicializar_Semaforo',['../semaforos_8c.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'Inicializar_Semaforo(int semid, unsigned short *array):&#160;semaforos.c'],['../semaforos_8h.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'Inicializar_Semaforo(int semid, unsigned short *array):&#160;semaforos.c']]]
];
