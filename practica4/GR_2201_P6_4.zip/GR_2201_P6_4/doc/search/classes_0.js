var searchData=
[
  ['_5fmensaje',['_mensaje',['../struct__mensaje.html',1,'']]]
];
